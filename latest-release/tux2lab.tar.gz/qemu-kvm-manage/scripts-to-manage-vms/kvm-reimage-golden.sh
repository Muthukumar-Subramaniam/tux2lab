#!/usr/bin/env bash
#----------------------------------------------------------------------------------------#
# If you encounter any issues with this script, or have suggestions or feature requests, #
# please open an issue at: https://github.com/Muthukumar-Subramaniam/tux2lab/issues   #
#----------------------------------------------------------------------------------------#
set -euo pipefail

source /tux2lab/common-utils/color-functions.sh
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/defaults.sh
DIR_PATH_SCRIPTS_TO_MANAGE_VMS='/tux2lab/qemu-kvm-manage/scripts-to-manage-vms'

ATTACH_CONSOLE="no"
RESET_SPECS="no"
FORCE_REIMAGE="false"
OS_DISTRO=""
VERSION_TYPE=""
HOSTNAMES=()
SUPPORTS_RESET_SPECS="yes"
SUPPORTS_FORCE="yes"
SUPPORTS_DISTRO="yes"
SUPPORTS_VERSION="yes"
SUPPORTS_STACK="yes"
STACK_MODE="dual"
STACK_MODE_EXPLICIT=false
VM_CPUS="2"
VM_CPUS_SPECIFIED=false
VM_MEMORY="2"
VM_MEMORY_SPECIFIED=false
VM_DISK_SIZE="30"
VM_DISK_SIZE_SPECIFIED=false

# Function to show help
fn_show_help() {
    print_cyan "Usage: tux2lab vm reimage-golden [OPTIONS]
Options:
  -H, --hosts          Specify hostname(s) (comma-separated for multiple VMs)
  -c, --console        Attach console during reimage (single VM only)
  --reset-specs-to-default     Destroy VM and reinstall with default specs (2 vCPUs, 2 GiB RAM, 30 GiB disk)
  -d, --distro         Specify OS distribution
                       (almalinux, rocky, oraclelinux, centos-stream, rhel, ubuntu-lts, debian, opensuse-leap, azure-linux)
  -v, --version        Specify OS version number (e.g., 10, 9, 26.04, 16.0, 3.0)
  --ipv4-only          Reimage as IPv4-only VM
  --ipv6-only          Reimage as IPv6-only VM (golden-boot handles the rest)
  --dual-stack         Force dual-stack (override auto-detected single-stack on reimage)
  --cpu <n>             Number of vCPUs (default: 2)
  --memory <n>        RAM in GiB (power of 2, default: 2)
  --root-disk-size <GiB>  Root disk size in GiB (default: 30)
  -f, --force          Skip confirmation prompt
  -h, --help           Show this help message

Examples:
  tux2lab vm reimage-golden -H vm1                                   # Reimage single VM
  tux2lab vm reimage-golden -H vm1 --console                         # Reimage and attach console
  tux2lab vm reimage-golden -H vm1 --reset-specs-to-default                   # Reimage with default specs
  tux2lab vm reimage-golden -H vm1 --distro almalinux                # Reimage with AlmaLinux (will prompt for version)
  tux2lab vm reimage-golden -H vm1 -d ubuntu-lts -v 26.04            # Reimage with Ubuntu 26.04
  tux2lab vm reimage-golden -f -H vm1                                # Reimage without confirmation
  tux2lab vm reimage-golden -H vm1,vm2,vm3 -d ubuntu-lts -v 26.04   # Reimage multiple with Ubuntu 26.04
  tux2lab vm reimage-golden -H vm1,vm2,vm3 --reset-specs-to-default           # Reimage multiple with defaults
"
}

# Parse and validate arguments
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/parse-vm-command-args.sh
parse_vm_command_args "$@"

# Validate: if --version is specified without --distro, warn user
if [[ -n "$VERSION_TYPE" && -z "$OS_DISTRO" ]]; then
    print_warning "The --version option is specified without --distro."
    print_info "The version will be applied if OS is auto-detected from hostname pattern."
    print_info "If auto-detection fails, you'll be prompted to select OS distribution interactively."
    echo ""
fi

# Save command-line distro and version if specified
CMDLINE_OS_DISTRO="$OS_DISTRO"
CMDLINE_VERSION_TYPE="$VERSION_TYPE"

# Validate distro and version locally before any work
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/validate-distro-version.sh
validate_distro_version "$CMDLINE_OS_DISTRO" "$CMDLINE_VERSION_TYPE"

# Main reimage loop
CURRENT_VM=0
FAILED_VMS=()
SUCCESSFUL_VMS=()
SKIPPED_VMS=()

source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/vm-hostname-lock.sh
trap 'fn_release_vm_hostname_lock' EXIT

for qemu_kvm_hostname in "${HOSTNAMES[@]}"; do
    # Reset OS_DISTRO and VERSION_TYPE to command-line values for each VM
    OS_DISTRO="$CMDLINE_OS_DISTRO"
    VERSION_TYPE="$CMDLINE_VERSION_TYPE"
    NORMALIZED_DISTRO=""
    
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/show-multi-vm-progress.sh
    show_multi_vm_progress "$qemu_kvm_hostname"

    # Check if VM exists
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/check-vm-exists.sh
    if ! check_vm_exists "$qemu_kvm_hostname" "reimage"; then
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # Confirm reimage operation
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/confirm-reimage-operation.sh
    if ! confirm_reimage_operation "$qemu_kvm_hostname" "golden image"; then
        SKIPPED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # Acquire per-hostname lock to prevent duplicate operations
    if ! fn_acquire_vm_hostname_lock "$qemu_kvm_hostname"; then
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # If --distro not specified, look up previous provisioning data
    if [[ -z "$OS_DISTRO" ]]; then
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/lookup-previous-provision.sh
        if lookup_previous_provision "$qemu_kvm_hostname"; then
            OS_DISTRO="$PREVIOUS_OS_DISTRO"
            VERSION_TYPE="$PREVIOUS_VERSION"
            print_info "Auto-detected previous OS: ${OS_DISTRO} ${VERSION_TYPE}"
        else
            # Auto-detect failed — prompt user
            print_warning "Could not detect previous OS for '${qemu_kvm_hostname}'."
            source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/select-distro-version.sh
            select_distro_version "" ""
            OS_DISTRO="$SELECTED_DISTRO"
            VERSION_TYPE="$SELECTED_VERSION"
        fi
    fi

    # Check if golden image exists for specified distro and version
    if [[ -n "$OS_DISTRO" && -n "$VERSION_TYPE" ]]; then
        # Normalize OS distro name first for golden image check
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/normalize-os-distro.sh
        if ! normalize_os_distro "${OS_DISTRO}"; then
            print_error "Invalid OS distribution: $OS_DISTRO"
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
        NORMALIZED_DISTRO="$NORMALIZED_OS_DISTRO"
        
        # Golden images follow pattern: {distro}-{version}-golden-image.{domain}.qcow2
        golden_image_pattern="${NORMALIZED_DISTRO}-${VERSION_TYPE//\./-}-golden-image.*.qcow2"
        if ! ls /tux2lab-data/golden-images-disk-store/${golden_image_pattern} &>/dev/null; then
            print_error "Golden image not found for '${OS_DISTRO}' (${VERSION_TYPE})"
            print_info "Available golden images:"
            source /tux2lab/ksmanager/distro-versions.conf
            if ls /tux2lab-data/golden-images-disk-store/*.qcow2 &>/dev/null; then
                for f in /tux2lab-data/golden-images-disk-store/*.qcow2; do
                    base=$(basename "$f" .qcow2)
                    prefix="${base%%-golden-image.*}"
                    for known_distro in "${!DISTRO_DISPLAY_NAMES[@]}"; do
                        if [[ "$prefix" == "${known_distro}-"* ]]; then
                            ver="${prefix#${known_distro}-}"
                            echo "  - ${known_distro} (${ver//-/.})"
                            break
                        fi
                    done
                done | sort -u
            else
                echo "  (none)"
            fi
            print_info "Use 'tux2lab golden-image build ${OS_DISTRO} -v ${VERSION_TYPE}' to create it"
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
    fi

    # Run ksmanager and extract VM details
    # Handle MAC address based on operation type
    if [[ "$RESET_SPECS" == "yes" ]]; then
        # For reset-specs, generate new MAC (VM will be destroyed and recreated)
        print_task "Generating MAC address..."
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/generate-mac-address.sh
        if ! GENERATED_MAC=$(generate_unique_mac "${qemu_kvm_hostname}"); then
            print_task_fail
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
        print_task_done
    else
        # For regular reimage, preserve existing MAC
        print_task "Getting MAC address from existing VM..."
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/get-vm-mac-address.sh
        if ! GENERATED_MAC=$(get_vm_mac_address "${qemu_kvm_hostname}"); then
            print_task_fail
            print_error "Failed to get MAC address from VM \"${qemu_kvm_hostname}\"."
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
        print_task_done
    fi

    print_info "Creating first boot environment via ksmanager..."

    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/run-ksmanager.sh
    ksmanager_opts="--qemu-kvm --golden-image --mac ${GENERATED_MAC} --distro $OS_DISTRO --version $VERSION_TYPE"
    if [[ "${STACK_MODE_EXPLICIT}" == "true" ]] || [[ "${STACK_MODE}" != "dual" ]]; then
        [[ "${STACK_MODE}" == "dual" ]] && ksmanager_opts="${ksmanager_opts} --dual-stack" || ksmanager_opts="${ksmanager_opts} --${STACK_MODE}-only"
    fi
    if ! run_ksmanager "${qemu_kvm_hostname}" "$ksmanager_opts"; then
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # Use the normalized distro from earlier validation, not the extracted OS name from ksmanager
    if [[ -n "$NORMALIZED_DISTRO" ]]; then
        OS_DISTRO="$NORMALIZED_DISTRO"
    else
        # If no --distro was specified, normalize the extracted OS name from ksmanager output
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/normalize-os-distro.sh
        if ! normalize_os_distro "${OS_DISTRO}"; then
            print_error "Failed to normalize OS distro for \"$qemu_kvm_hostname\"."
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
        OS_DISTRO="$NORMALIZED_OS_DISTRO"
    fi

    # Update /etc/hosts (skip temp IPv4 for --ipv6-only VMs)
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/update-etc-hosts.sh
    print_task "Updating /etc/hosts..."
    _etc_hosts_ipv4="${IPV4_ADDRESS}"
    [[ "${STACK_MODE}" == "ipv6" ]] && _etc_hosts_ipv4=""
    if ! add_etc_hosts_entry "${qemu_kvm_hostname}" "${_etc_hosts_ipv4}" "${IPV6_ADDRESS}"; then
        print_task_fail
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi
    print_task_done

    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/validate-golden-image-exists.sh
    if ! validate_golden_image_exists "$qemu_kvm_hostname" "${OS_DISTRO}" "${VERSION_TYPE}"; then
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # Construct golden image FQDN matching ksmanager's format
    golden_image_fqdn="${OS_DISTRO}-${VERSION_TYPE//\./-}-golden-image.${lab_infra_domain_name}"
    golden_qcow2_disk_path="/tux2lab-data/golden-images-disk-store/${golden_image_fqdn}.qcow2"

    # Shut down VM if running
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/poweroff-vm.sh
    if ! POWEROFF_VM_CONTEXT="Powering off before reimaging" POWEROFF_VM_STRICT=true poweroff_vm "$qemu_kvm_hostname"; then
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # If --reset-specs-to-default is specified, destroy and reinstall VM with default specs
    if [[ "$RESET_SPECS" == "yes" ]]; then
        print_info "Using --reset-specs-to-default: VM will be destroyed and reinstalled with default specs (2 vCPUs, 2 GiB RAM, 30 GiB disk)."
        
        # Destroy VM and delete directory
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/destroy-vm-for-reset-specs.sh
        if ! destroy_vm_for_reset_specs "$qemu_kvm_hostname"; then
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
        
        # Create fresh VM directory
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/create-vm-directory.sh
        if ! create_vm_directory "${qemu_kvm_hostname}"; then
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
        
        # Clone golden image disk
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/clone-golden-image-disk.sh
        if ! clone_golden_image_disk "$qemu_kvm_hostname" "${OS_DISTRO}" "${VERSION_TYPE}"; then
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
        
        # Install VM with default specs using default-vm-install function
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/select-ovmf.sh
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/start-vm-installation.sh
        if ! start_vm_installation "$qemu_kvm_hostname" "golden image disk with default specs"; then
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
    else
        # Default path: preserve existing specs unless explicitly overridden
        print_task "Reimaging by replacing qcow2 disk..."
        
        # Apply CPU/memory overrides to the shut-off VM's definition
        if [[ "$VM_CPUS_SPECIFIED" == "true" ]]; then
            if ! sudo virsh setvcpus "$qemu_kvm_hostname" "$VM_CPUS" --config --maximum >/dev/null 2>&1 || 
               ! sudo virsh setvcpus "$qemu_kvm_hostname" "$VM_CPUS" --config >/dev/null 2>&1; then
                print_warning "Could not apply --cpu ${VM_CPUS} override. VM will keep existing CPU count."
            fi
        fi
        if [[ "$VM_MEMORY_SPECIFIED" == "true" ]]; then
            new_mem_kib=$(( VM_MEMORY * 1024 * 1024 ))
            if ! sudo virsh setmaxmem "$qemu_kvm_hostname" "${new_mem_kib}" --config >/dev/null 2>&1 || 
               ! sudo virsh setmem "$qemu_kvm_hostname" "${new_mem_kib}" --config >/dev/null 2>&1 || 
               ! sudo virsh setmaxmem "$qemu_kvm_hostname" "${new_mem_kib}" --config >/dev/null 2>&1; then
                print_warning "Could not apply --memory ${VM_MEMORY} override. VM will keep existing memory."
            fi
        fi

        vm_qcow2_disk_path="/tux2lab-data/vms/${qemu_kvm_hostname}/${qemu_kvm_hostname}.qcow2"
        
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/get-current-disk-size.sh
        get_current_disk_size "$qemu_kvm_hostname"
        current_disk_gib="${CURRENT_DISK_SIZE:-30}"
        
        golden_disk_gib=$(sudo qemu-img info -U "${golden_qcow2_disk_path}" 2>/dev/null | awk '/virtual size/ {for(i=1;i<=NF;i++) if($i ~ /^[0-9]+$/ && $(i+1)=="GiB") {print $i; exit}}' || true)
        golden_disk_gib="${golden_disk_gib:-30}"
        
        # Use user-specified disk size if provided, otherwise preserve current
        target_disk_gib="${current_disk_gib}"
        [[ "$VM_DISK_SIZE_SPECIFIED" == "true" ]] && target_disk_gib="${VM_DISK_SIZE}"

        # Delete existing qcow2 disk and recreate with appropriate size
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/delete-vm-disk.sh
        delete_vm_disk "$qemu_kvm_hostname"
        
        if ! sudo qemu-img convert -O qcow2 "${golden_qcow2_disk_path}" "${vm_qcow2_disk_path}" >/dev/null 2>&1; then
            print_task_fail
            print_error "Failed to convert golden image disk for \"$qemu_kvm_hostname\"."
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
        print_task_done
        
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/resize-disk-if-larger.sh
        resize_disk_if_larger "$qemu_kvm_hostname" "$target_disk_gib" "$golden_disk_gib"
        
        # Start reimaging process
        source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/start-vm-for-reimage.sh
        if ! start_vm_for_reimage "$qemu_kvm_hostname"; then
            fn_release_vm_hostname_lock
            FAILED_VMS+=("$qemu_kvm_hostname")
            continue
        fi
    fi

    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/report-retained-resources.sh
    report_retained_resources "$qemu_kvm_hostname"

    fn_release_vm_hostname_lock
    SUCCESSFUL_VMS+=("$qemu_kvm_hostname")

    # Show completion message for single VM
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/show-vm-completion-message.sh
    show_vm_completion_message "${qemu_kvm_hostname}" "${ATTACH_CONSOLE}" "${TOTAL_VMS}" "Reimage" "Reimaging via golden image disk takes ~1 minute."
done

# Summary for multiple VMs
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/show-vm-operation-summary.sh
if ! show_vm_operation_summary "${TOTAL_VMS}" "SUCCESSFUL_VMS" "FAILED_VMS" "reimaging via golden image disk" "Reimaging via golden image disk takes ~1 minute per VM." "SKIPPED_VMS"; then
    exit 1
fi




