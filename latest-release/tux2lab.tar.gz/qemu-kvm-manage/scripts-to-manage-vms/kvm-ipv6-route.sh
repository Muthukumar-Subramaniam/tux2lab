#!/usr/bin/env bash

# IPv6 Default Route Manager for Lab VMs
# Purpose: Enable/disable IPv6 default gateway when QEMU host has/loses IPv6 internet connectivity
# Usage: Run from QEMU host to manage routes on all running VMs

set -uo pipefail

# Source color functions
source /tux2lab/common-utils/color-functions.sh

# Source lab environment
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/defaults.sh
source /tux2lab/shared-functions/lab-state.sh

# Validate required variables
if [[ ! -f "${LAB_ENV_JSON}" ]]; then
    print_error "Lab environment config not found: ${LAB_ENV_JSON}"
    print_info "Deploy the lab first with: tux2lab deploy"
    exit 1
fi
lab_infra_server_ipv6_gateway=$(jq -r '.network.ipv6.gateway' "${LAB_ENV_JSON}")
lab_infra_server_ipv6_ula_subnet=$(jq -r '.network.ipv6.ula_subnet' "${LAB_ENV_JSON}")
if [[ -z "${lab_infra_server_ipv6_gateway}" || "${lab_infra_server_ipv6_gateway}" == "null" ]]; then
    print_error "IPv6 gateway not configured in lab environment."
    print_info "Redeploy with: tux2lab rebuild"
    exit 1
fi

if [[ -z "${lab_infra_admin_username:-}" ]]; then
    print_error "Admin username not configured in lab environment."
    print_info "Redeploy with: tux2lab rebuild"
    exit 1
fi

IPV6_TEST_HOST="2001:4860:4860::8888"  # Google Public DNS IPv6
IPV6_GATEWAY="${lab_infra_server_ipv6_gateway}"

# SSH options for connecting to VMs
ssh_options=(
    -o StrictHostKeyChecking=no
    -o UserKnownHostsFile=/dev/null
    -o LogLevel=QUIET
    -o ConnectTimeout=2
    -o PasswordAuthentication=no
    -o PubkeyAuthentication=yes
    -o PreferredAuthentications=publickey
    -o BatchMode=yes
)

fn_usage() {
    print_cyan "USAGE:
    tux2lab ipv6-route <subcommand>

DESCRIPTION:
    Manage IPv6 default routes on running lab VMs. Enable or disable
    internet-bound IPv6 routing based on host connectivity.
    Local IPv6 subnet routes are always present regardless of this setting.

SUBCOMMANDS:
    enable      Enable IPv6 default route on all running VMs
    disable     Disable IPv6 default route on all running VMs
    check       Check IPv6 internet connectivity and current route status
    auto        Automatically enable/disable based on host connectivity
    status      Show IPv6 route status for all VMs

EXAMPLES:
    tux2lab ipv6-route enable      # Enable IPv6 default route
    tux2lab ipv6-route disable     # Remove IPv6 default route
    tux2lab ipv6-route check       # Test connectivity and show status
    tux2lab ipv6-route auto        # Auto-configure based on connectivity"
}

fn_test_ipv6_connectivity() {
    print_task "Testing IPv6 internet connectivity from host..."
    
    if ping6 -c 2 -W 3 "$IPV6_TEST_HOST" &>/dev/null; then
        print_task_done
        print_success "IPv6 internet connectivity available."
        return 0
    else
        print_task_fail
        print_warning "No IPv6 internet connectivity."
        return 1
    fi
}

fn_get_running_vms() {
    sudo virsh list --name | grep -v "^$" || true
}

fn_vm_is_ssh_ready() {
    local vm_name="$1"
    nc -z -w 1 "$vm_name" 22 &>/dev/null
    return $?
}

fn_trigger_sync_on_vm() {
    local vm_name="$1"
    
    if ! fn_vm_is_ssh_ready "$vm_name"; then
        print_warning "VM $vm_name: SSH not ready, will sync on next cycle"
        return 1
    fi
    
    if ssh "${ssh_options[@]}" "${lab_infra_admin_username}@${vm_name}" \
        'sudo /usr/local/bin/tux2lab-sync' &>/dev/null; then
        print_success "VM $vm_name: sync triggered"
        return 0
    else
        print_warning "VM $vm_name: sync failed, will retry on next cycle"
        return 1
    fi
}

fn_check_vm_ipv6_route() {
    local vm_name="$1"
    
    if ! fn_vm_is_ssh_ready "$vm_name"; then
        echo "  $vm_name: [SSH not ready]"
        return 1
    fi
    
    local route_check=$(ssh "${ssh_options[@]}" "${lab_infra_admin_username}@${vm_name}" \
        'sudo ip -6 route show default' 2>/dev/null)
    
    if [[ "$route_check" =~ "default" ]]; then
        echo "  $vm_name: $(print_green "[IPv6 default route: ENABLED]")"
    else
        echo "  $vm_name: $(print_yellow "[IPv6 default route: DISABLED]")"
    fi
}

fn_enable_host_ipv6_forwarding() {
    print_task "Enabling IPv6 forwarding on host..."
    
    # Enable IPv6 forwarding
    sudo sysctl -w net.ipv6.conf.all.forwarding=1 &>/dev/null
    
    # Keep accepting Router Advertisements on primary interface
    local primary_if=$(ip route | awk '/default/ {print $5; exit}')
    if [[ ! -z "${primary_if}" ]]; then
        sudo sysctl -w net.ipv6.conf.${primary_if}.accept_ra=2 &>/dev/null
    fi
    
    # Enable NAT66 for ULA subnet so VMs can reach internet via host's global IPv6
    if [[ ! -z "${lab_infra_server_ipv6_ula_subnet:-}" ]] && [[ ! -z "${primary_if}" ]]; then
        # Add NAT66 masquerading for ULA subnet
        if ! sudo ip6tables -t nat -C POSTROUTING -s ${lab_infra_server_ipv6_ula_subnet} -o ${primary_if} -j MASQUERADE 2>/dev/null; then
            sudo ip6tables -t nat -A POSTROUTING -s ${lab_infra_server_ipv6_ula_subnet} -o ${primary_if} -j MASQUERADE &>/dev/null
        fi
        
        # Add forwarding rules
        if ! sudo ip6tables -C FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null; then
            sudo ip6tables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT &>/dev/null
        fi
        
        if ! sudo ip6tables -C FORWARD -i labbr0 -o ${primary_if} -j ACCEPT 2>/dev/null; then
            sudo ip6tables -A FORWARD -i labbr0 -o ${primary_if} -j ACCEPT &>/dev/null
        fi
    fi
    
    print_task_done
}

fn_disable_host_ipv6_forwarding() {
    # Check if there's anything to disable
    local forwarding_enabled=false
    local nat_rules_exist=false

    if [[ "$(cat /proc/sys/net/ipv6/conf/all/forwarding 2>/dev/null)" == "1" ]]; then
        forwarding_enabled=true
    fi

    local primary_if=$(ip route | awk '/default/ {print $5; exit}')
    if [[ -n "${lab_infra_server_ipv6_ula_subnet:-}" ]] && [[ -n "${primary_if}" ]]; then
        if sudo ip6tables -t nat -C POSTROUTING -s ${lab_infra_server_ipv6_ula_subnet} -o ${primary_if} -j MASQUERADE 2>/dev/null; then
            nat_rules_exist=true
        fi
    fi

    if ! $forwarding_enabled && ! $nat_rules_exist; then
        print_info "IPv6 forwarding and NAT rules already disabled on host"
        return 0
    fi

    print_task "Disabling IPv6 forwarding and NAT rules on host..."
    
    # Remove NAT66 and forwarding rules
    if [[ -n "${lab_infra_server_ipv6_ula_subnet:-}" ]] && [[ -n "${primary_if}" ]]; then
        sudo ip6tables -t nat -D POSTROUTING -s ${lab_infra_server_ipv6_ula_subnet} -o ${primary_if} -j MASQUERADE 2>/dev/null || true
        sudo ip6tables -D FORWARD -i labbr0 -o ${primary_if} -j ACCEPT 2>/dev/null || true
        sudo ip6tables -D FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null || true
    fi
    
    # Disable IPv6 forwarding
    sudo sysctl -w net.ipv6.conf.all.forwarding=0 &>/dev/null
    
    print_task_done
}

fn_enable_all() {
    print_notify "Enabling IPv6 default route on all running VMs..."
    echo ""
    
    # First, test if IPv6 internet is available
    if ! fn_test_ipv6_connectivity; then
        echo ""
        print_error "Cannot enable IPv6 default routes: No IPv6 internet connectivity"
        print_info "Routes will not be configured until IPv6 internet is available"
        print_info "Use 'tux2lab ipv6-route auto' to auto-configure based on connectivity"
        return 1
    fi
    
    echo ""
    
    # Enable host-level forwarding and NAT
    fn_enable_host_ipv6_forwarding
    echo ""
    
    # Set flag BEFORE triggering sync so VMs see the new state
    echo "enabled" > /tux2lab-data/lab-config/ipv6-route-active

    local vms=$(fn_get_running_vms)
    
    if [[ -z "$vms" ]]; then
        print_warning "No running VMs found"
        return 0
    fi
    
    for vm in $vms; do
        fn_trigger_sync_on_vm "$vm"
    done
    
    echo ""
    print_success "IPv6 default route configuration complete."
}

fn_disable_all() {
    print_notify "Disabling IPv6 default route on all running VMs..."
    echo ""
    
    # Remove flag BEFORE triggering sync so VMs see the new state
    rm -f /tux2lab-data/lab-config/ipv6-route-active

    local vms=$(fn_get_running_vms)
    
    if [[ -z "$vms" ]]; then
        print_warning "No running VMs found"
    else
        for vm in $vms; do
            fn_trigger_sync_on_vm "$vm"
        done
        
        echo ""
        print_success "IPv6 default route removal complete."
    fi

    # Clean up host-level forwarding and NAT rules
    fn_disable_host_ipv6_forwarding
}

fn_auto_configure() {
    print_notify "Auto-configuring IPv6 default routes based on connectivity..."
    echo ""
    
    if fn_test_ipv6_connectivity; then
        echo ""
        print_info "IPv6 internet available → Enabling default routes"
        fn_enable_all
    else
        echo ""
        # Check if already in the correct state
        local forwarding_enabled=false
        if [[ "$(cat /proc/sys/net/ipv6/conf/all/forwarding 2>/dev/null)" == "1" ]]; then
            forwarding_enabled=true
        fi
        if $forwarding_enabled; then
            print_info "No IPv6 internet → Disabling default routes"
            fn_disable_all
        else
            print_info "No IPv6 internet. Routes already disabled — nothing to do."
        fi
    fi
}

fn_show_status() {
    print_notify "IPv6 Configuration Status"
    echo ""
    
    # Test host connectivity
    print_info "Host IPv6 Internet:" "nskip"
    if ping6 -c 2 -W 3 "$IPV6_TEST_HOST" &>/dev/null; then
        print_green " [AVAILABLE]"
    else
        print_yellow " [NOT AVAILABLE]"
    fi
    
    echo ""
    print_info "VM IPv6 Default Routes:"
    echo ""
    
    local vms=$(fn_get_running_vms)
    
    if [[ -z "$vms" ]]; then
        print_warning "No running VMs found"
        return 0
    fi
    
    for vm in $vms; do
        fn_check_vm_ipv6_route "$vm"
    done
    
    echo ""
    print_info "Note: Local IPv6 subnet (${lab_infra_server_ipv6_ula_subnet}) is always accessible"
}

fn_check_and_report() {
    fn_show_status
    echo ""
    print_notify "Recommendation:"
    
    if ping6 -c 2 -W 3 "$IPV6_TEST_HOST" &>/dev/null; then
        print_info "IPv6 internet is available. Run 'tux2lab ipv6-route enable' to enable default routes."
    else
        print_info "No IPv6 internet. Current configuration (routes disabled) is optimal."
    fi
}

# Main execution
if [[ $# -eq 0 ]]; then
    fn_usage
    exit 0
fi

case "${1}" in
    enable)
        fn_require_lab_running
        fn_enable_all
        ;;
    disable)
        fn_require_lab_running
        fn_disable_all
        ;;
    auto)
        fn_require_lab_running
        fn_auto_configure
        ;;
    check)
        fn_require_lab_running
        fn_check_and_report
        ;;
    status)
        fn_require_lab_running
        fn_show_status
        ;;
    -h|--help)
        fn_usage
        ;;
    *)
        print_error "Unknown argument: $1"
        echo "Run 'tux2lab ipv6-route --help' for usage information."
        exit 1
        ;;
esac
