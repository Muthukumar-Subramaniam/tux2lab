#!/usr/bin/env bash
#----------------------------------------------------------------------------------------#
# If you encounter any issues with this script, or have suggestions or feature requests, #
# please open an issue at: https://github.com/Muthukumar-Subramaniam/tux2lab/issues   #
#----------------------------------------------------------------------------------------#
set -euo pipefail

source /tux2lab/common-utils/color-functions.sh
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/defaults.sh
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/select-ovmf.sh

ATTACH_CONSOLE="no"
OS_DISTRO=""
VERSION_TYPE=""
HOSTNAMES=()
SUPPORTS_DISTRO="yes"
SUPPORTS_VERSION="yes"
SUPPORTS_STACK="yes"
STACK_MODE="dual"
STACK_MODE_EXPLICIT=false
VM_CPUS="2"
VM_CPUS_SPECIFIED=false
VM_MEMORY="2"
VM_MEMORY_SPECIFIED=false
VM_DISK_SIZE="30"
VM_DISK_SIZE_SPECIFIED=false

# Function to show help
fn_show_help() {
    print_cyan "USAGE:
    tux2lab vm install [--via-golden] [OPTIONS]

DESCRIPTION:
    Deploy new VM(s) from golden image (fast disk clone). Supports per-VM
    stack mode selection (dual/IPv4/IPv6), custom resource specs (CPU,
    memory, disk), multi-VM batch deployment, and console attachment for
    monitoring golden-boot configuration.

OPTIONS:
    -H <hostnames>      Hostname(s) to deploy (comma-separated)
    -d <distro>         OS distribution
    -v <version>        OS version
    -c, --console       Attach to serial console (single VM only)
    --ipv4-only         Create IPv4-only VM
    --ipv6-only         Create IPv6-only VM
    --dual-stack        Create dual-stack VM (default if neither is specified)
    --cpu <n>           vCPUs (power of 2, default: 2)
    --memory <n>        RAM in GiB (power of 2, default: 2)
    --root-disk-size <n> Disk in GiB (multiple of 5, default: 30)
    -h, --help          Show this help message

EXAMPLES:
    tux2lab vm install -H testvm1
    tux2lab vm install -H testvm1 -d almalinux -v 10
    tux2lab vm install -H testvm1 --console
    tux2lab vm install -H testvm1 --ipv4-only -d rocky -v 9
    tux2lab vm install -H testvm1 --cpu 4 --memory 8 --root-disk-size 50
    tux2lab vm install -H testvm1,testvm2,testvm3
    tux2lab vm install -H testvm1,testvm2,testvm3 -d ubuntu-lts -v 26.04
"
}

# Parse and validate arguments
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/parse-vm-command-args.sh
parse_vm_command_args "$@"

# Save command-line distro and version if specified
CMDLINE_OS_DISTRO="$OS_DISTRO"
CMDLINE_VERSION_TYPE="$VERSION_TYPE"

# Validate distro and version locally before any work
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/validate-distro-version.sh
validate_distro_version "$CMDLINE_OS_DISTRO" "$CMDLINE_VERSION_TYPE"

# If no distro/version specified on cmdline, select from available golden images
if [[ -z "$CMDLINE_OS_DISTRO" || -z "$CMDLINE_VERSION_TYPE" ]]; then
    source /tux2lab/ksmanager/distro-versions.conf
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/normalize-os-distro.sh

    # Discover available golden images
    declare -a GOLDEN_IMAGES_AVAILABLE=()
    if [[ -d /tux2lab-data/golden-images-disk-store ]]; then
        for f in /tux2lab-data/golden-images-disk-store/*.qcow2; do
            [[ -f "$f" ]] || continue
            base=$(basename "$f" .qcow2)
            # Strip the -golden-image.{domain} suffix
            prefix="${base%%-golden-image.*}"
            # Match against known distros to extract distro + version
            for known_distro in "${!DISTRO_DISPLAY_NAMES[@]}"; do
                if [[ "$prefix" == "${known_distro}-"* ]]; then
                    ver="${prefix#${known_distro}-}"
                    ver="${ver//-/.}"
                    GOLDEN_IMAGES_AVAILABLE+=("${known_distro}:${ver}")
                    break
                fi
            done
        done
    fi

    if [[ ${#GOLDEN_IMAGES_AVAILABLE[@]} -eq 0 ]]; then
        print_error "No golden images found in /tux2lab-data/golden-images-disk-store/"
        print_info "Build one first: tux2lab golden-image build"
        exit 1
    fi

    # If distro specified but not version, filter to that distro
    if [[ -n "$CMDLINE_OS_DISTRO" && -z "$CMDLINE_VERSION_TYPE" ]]; then
        normalize_os_distro "$CMDLINE_OS_DISTRO" || { print_error "Invalid distro: $CMDLINE_OS_DISTRO"; exit 1; }
        local_filter_distro="$NORMALIZED_OS_DISTRO"
        declare -a FILTERED_IMAGES=()
        for entry in "${GOLDEN_IMAGES_AVAILABLE[@]}"; do
            if [[ "${entry%%:*}" == "$local_filter_distro" ]]; then
                FILTERED_IMAGES+=("$entry")
            fi
        done
        if [[ ${#FILTERED_IMAGES[@]} -eq 0 ]]; then
            print_error "No golden images found for '${CMDLINE_OS_DISTRO}'"
            print_info "Available golden images:"
            for entry in "${GOLDEN_IMAGES_AVAILABLE[@]}"; do
                echo "  - ${entry%%:*} (${entry#*:})"
            done
            exit 1
        fi
        GOLDEN_IMAGES_AVAILABLE=("${FILTERED_IMAGES[@]}")
    fi

    # If only one golden image available, auto-select it
    if [[ ${#GOLDEN_IMAGES_AVAILABLE[@]} -eq 1 ]]; then
        CMDLINE_OS_DISTRO="${GOLDEN_IMAGES_AVAILABLE[0]%%:*}"
        CMDLINE_VERSION_TYPE="${GOLDEN_IMAGES_AVAILABLE[0]#*:}"
        print_info "Using golden image: ${DISTRO_DISPLAY_NAMES[$CMDLINE_OS_DISTRO]} ${CMDLINE_VERSION_TYPE}"
    else
        # If distro is known, show simple version prompt
        if [[ -n "$CMDLINE_OS_DISTRO" ]]; then
            local_versions=""
            for entry in "${GOLDEN_IMAGES_AVAILABLE[@]}"; do
                local_versions+="${entry#*:} "
            done
            local_versions=$(echo "$local_versions" | tr ' ' '\n' | sort -V | tr '\n' ' ')
            _display="${DISTRO_DISPLAY_NAMES[$CMDLINE_OS_DISTRO]:-$CMDLINE_OS_DISTRO}"
            while true; do
                echo "Available golden image versions for ${_display}: ${local_versions}"
                echo -n "Enter the version: "
                read -r _ver_input
                if [[ "$_ver_input" == "q" || "$_ver_input" == "Q" ]]; then
                    exit 130
                fi
                for entry in "${GOLDEN_IMAGES_AVAILABLE[@]}"; do
                    if [[ "${entry#*:}" == "$_ver_input" ]]; then
                        CMDLINE_OS_DISTRO="${entry%%:*}"
                        CMDLINE_VERSION_TYPE="$_ver_input"
                        break 2
                    fi
                done
                print_error "Invalid version '${_ver_input}'. Please try again."
            done
        else
            # No distro specified — show full golden image menu
            echo "Select golden image to deploy:"
            idx=1
            for entry in "${GOLDEN_IMAGES_AVAILABLE[@]}"; do
                gi_distro="${entry%%:*}"
                gi_version="${entry#*:}"
                printf "  %d)  %-24s %s\n" "$idx" "${DISTRO_DISPLAY_NAMES[$gi_distro]}" "$gi_version"
                idx=$((idx + 1))
            done
            printf "  q)  Quit\n"

            while true; do
                read -rp "Enter option number: " gi_choice
                if [[ "$gi_choice" == "q" || "$gi_choice" == "Q" ]]; then
                    print_info "Installation cancelled."
                    exit 0
                fi
                if [[ "$gi_choice" =~ ^[0-9]+$ ]] && (( gi_choice >= 1 && gi_choice <= ${#GOLDEN_IMAGES_AVAILABLE[@]} )); then
                    selected="${GOLDEN_IMAGES_AVAILABLE[$((gi_choice - 1))]}"
                    CMDLINE_OS_DISTRO="${selected%%:*}"
                    CMDLINE_VERSION_TYPE="${selected#*:}"
                    break
                fi
                print_error "Invalid option. Please try again."
            done
        fi
        print_info "Selected: ${DISTRO_DISPLAY_NAMES[$CMDLINE_OS_DISTRO]} ${CMDLINE_VERSION_TYPE}"
    fi
fi

# Verify golden image exists before any state-changing operations
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/normalize-os-distro.sh
normalize_os_distro "${CMDLINE_OS_DISTRO}" || { print_error "Invalid distro: $CMDLINE_OS_DISTRO"; exit 1; }
GOLDEN_IMAGE_CHECK_PATH="/tux2lab-data/golden-images-disk-store/${NORMALIZED_OS_DISTRO}-${CMDLINE_VERSION_TYPE//\./-}-golden-image.${lab_infra_domain_name}.qcow2"
if [[ ! -f "$GOLDEN_IMAGE_CHECK_PATH" ]]; then
    print_error "Golden image not found: ${NORMALIZED_OS_DISTRO}-${CMDLINE_VERSION_TYPE//\./-}-golden-image.${lab_infra_domain_name}.qcow2"
    print_info "Build one first: tux2lab golden-image build ${CMDLINE_OS_DISTRO} -v ${CMDLINE_VERSION_TYPE}"
    exit 1
fi

# Main installation loop
CURRENT_VM=0
FAILED_VMS=()
SUCCESSFUL_VMS=()

source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/vm-hostname-lock.sh
trap 'fn_release_vm_hostname_lock' EXIT

for qemu_kvm_hostname in "${HOSTNAMES[@]}"; do
    # Reset OS_DISTRO and VERSION_TYPE to command-line values for each VM
    OS_DISTRO="$CMDLINE_OS_DISTRO"
    VERSION_TYPE="$CMDLINE_VERSION_TYPE"
    
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/show-multi-vm-progress.sh
    show_multi_vm_progress "$qemu_kvm_hostname"

    # Check if VM exists
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/check-vm-exists.sh
    if ! check_vm_exists "$qemu_kvm_hostname" "install"; then
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # Acquire per-hostname lock to prevent duplicate operations
    if ! fn_acquire_vm_hostname_lock "$qemu_kvm_hostname"; then
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # Run ksmanager and extract VM details
    print_task "Generating MAC address..."
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/generate-mac-address.sh
    if ! GENERATED_MAC=$(generate_unique_mac "${qemu_kvm_hostname}"); then
        print_task_fail
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi
    print_task_done

    print_info "Creating first boot environment via ksmanager..."

    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/run-ksmanager.sh
    ksmanager_opts="--qemu-kvm --golden-image --mac ${GENERATED_MAC} --distro $OS_DISTRO --version $VERSION_TYPE"
    if [[ "${STACK_MODE_EXPLICIT}" == "true" ]] || [[ "${STACK_MODE}" != "dual" ]]; then
        [[ "${STACK_MODE}" == "dual" ]] && ksmanager_opts="${ksmanager_opts} --dual-stack" || ksmanager_opts="${ksmanager_opts} --${STACK_MODE}-only"
    fi
    cleanup_on_cancel=true  # Cleanup DNS/MAC if user cancels during install
    if ! run_ksmanager "${qemu_kvm_hostname}" "$ksmanager_opts" "$cleanup_on_cancel"; then
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # Normalize OS distro name for golden image lookup
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/normalize-os-distro.sh
    if ! normalize_os_distro "${OS_DISTRO}"; then
        print_error "Failed to normalize OS distro for \"$qemu_kvm_hostname\"."
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi
    OS_DISTRO="$NORMALIZED_OS_DISTRO"

    # Create VM directory
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/create-vm-directory.sh
    if ! create_vm_directory "${qemu_kvm_hostname}"; then
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # Update /etc/hosts (skip temp IPv4 for --ipv6-only VMs)
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/update-etc-hosts.sh
    print_task "Updating /etc/hosts..."
    _etc_hosts_ipv4="${IPV4_ADDRESS}"
    [[ "${STACK_MODE}" == "ipv6" ]] && _etc_hosts_ipv4=""
    if ! add_etc_hosts_entry "${qemu_kvm_hostname}" "${_etc_hosts_ipv4}" "${IPV6_ADDRESS}"; then
        print_task_fail
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi
    print_task_done

    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/clone-golden-image-disk.sh
    if ! clone_golden_image_disk "$qemu_kvm_hostname" "${OS_DISTRO}" "${VERSION_TYPE}"; then
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    # Start installation process via golden image disk
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/start-vm-installation.sh
    if ! start_vm_installation "$qemu_kvm_hostname" "golden image disk"; then
        fn_release_vm_hostname_lock
        FAILED_VMS+=("$qemu_kvm_hostname")
        continue
    fi

    fn_release_vm_hostname_lock
    SUCCESSFUL_VMS+=("$qemu_kvm_hostname")

    print_info "VM specs: ${VM_CPUS} vCPUs, ${VM_MEMORY} GiB RAM, ${VM_DISK_SIZE} GiB disk"

    # Show completion message for single VM
    source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/show-vm-completion-message.sh
    show_vm_completion_message "${qemu_kvm_hostname}" "${ATTACH_CONSOLE}" "${TOTAL_VMS}" "Installation" "Installation via golden image disk takes ~1 minute per VM."
done

# Summary for multiple VMs
source /tux2lab/qemu-kvm-manage/scripts-to-manage-vms/functions/show-vm-operation-summary.sh
if ! show_vm_operation_summary "${TOTAL_VMS}" "SUCCESSFUL_VMS" "FAILED_VMS" "installation via golden image disk" "Installation via golden image disk takes ~1 minute per VM."; then
    exit 1
fi
