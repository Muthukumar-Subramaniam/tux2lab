# parse-vm-control-args.sh
# 
# Parses common arguments for VM control scripts (start/stop/shutdown/reboot/restart/remove)
#
# Usage:
#   SUPPORTS_FORCE="yes"  # Set to "yes" if script supports -f/--force flag
#   SUPPORTS_IGNORE_KSMANAGER="yes"  # Set to "yes" if script supports --ignore-ksmanager-cleanup flag
#   source /path/to/parse-vm-control-args.sh
#   parse_vm_control_args "$@"
#
# Sets global variables:
#   FORCE_FLAG - true/false (only if SUPPORTS_FORCE="yes")
#   IGNORE_KSMANAGER_CLEANUP - true/false (only if SUPPORTS_IGNORE_KSMANAGER="yes")
#   HOSTS_LIST - comma-separated list of hostnames (if --hosts provided)
#   VM_HOSTNAME_ARG - single hostname argument (if provided)
#
# Note: Script must define fn_show_help() function before sourcing this

parse_vm_control_args() {
    # Initialize variables based on script support
    if [[ "${SUPPORTS_FORCE:-no}" == "yes" ]]; then
        FORCE_FLAG=false
    fi
    if [[ "${SUPPORTS_IGNORE_KSMANAGER:-no}" == "yes" ]]; then
        IGNORE_KSMANAGER_CLEANUP=false
        KSMANAGER_CLEANUP_ONLY=false
    fi
    HOSTS_LIST=""
    VM_HOSTNAME_ARG=""
    
    # Parse options
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -h|--help)
                fn_show_help
                exit 0
                ;;
            -f|--force)
                if [[ "${SUPPORTS_FORCE:-no}" == "yes" ]]; then
                    FORCE_FLAG=true
                    shift
                else
                    print_error "No such option: $1"
                    fn_show_help
                    exit 1
                fi
                ;;
            --ignore-ksmanager-cleanup)
                if [[ "${SUPPORTS_IGNORE_KSMANAGER:-no}" == "yes" ]]; then
                    IGNORE_KSMANAGER_CLEANUP=true
                    shift
                else
                    print_error "No such option: $1"
                    fn_show_help
                    exit 1
                fi
                ;;
            --ksmanager-cleanup-only)
                if [[ "${SUPPORTS_IGNORE_KSMANAGER:-no}" == "yes" ]]; then
                    KSMANAGER_CLEANUP_ONLY=true
                    shift
                else
                    print_error "No such option: $1"
                    fn_show_help
                    exit 1
                fi
                ;;
            -H|--hosts)
                if [[ -z "${2:-}" || "${2:-}" == -* ]]; then
                    print_error "--hosts requires a comma-separated list of hostnames."
                    fn_show_help
                    exit 1
                fi
                HOSTS_LIST="$2"
                shift 2
                ;;
            -*)
                print_error "No such option: $1"
                fn_show_help
                exit 1
                ;;
            *)
                print_error "Unexpected argument: $1"
                print_info "Use -H/--hosts to specify hostname(s)."
                fn_show_help
                exit 1
                ;;
        esac
    done

    if [[ "${IGNORE_KSMANAGER_CLEANUP:-false}" == "true" ]] && [[ "${KSMANAGER_CLEANUP_ONLY:-false}" == "true" ]]; then
        print_error "--ignore-ksmanager-cleanup and --ksmanager-cleanup-only cannot be used together."
        exit 1
    fi
}
