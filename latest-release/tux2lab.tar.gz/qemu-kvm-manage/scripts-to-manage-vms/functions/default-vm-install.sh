# Set default values if not provided (memory in GiB, converted to MiB for virt-install)
DISK_PATH="${DISK_PATH:-/tux2lab-data/vms/${qemu_kvm_hostname}/${qemu_kvm_hostname}.qcow2}"
NVRAM_PATH="${NVRAM_PATH:-/tux2lab-data/vms/${qemu_kvm_hostname}/${qemu_kvm_hostname}_VARS.fd}"
VM_CPUS="${VM_CPUS:-2}"
VM_MEMORY="${VM_MEMORY:-2}"
VM_DISK_SIZE="${VM_DISK_SIZE:-30}"
VM_MEMORY_MIB=$(( VM_MEMORY * 1024 ))

VENDORED_VIRT_MANAGER_DIR="/tux2lab/vendor/virt-manager"

if ! virt_install_error=$(sudo PYTHONPATH="${VENDORED_VIRT_MANAGER_DIR}" python3 "${VENDORED_VIRT_MANAGER_DIR}/virt-install" \
  --name "${qemu_kvm_hostname}" \
  --features acpi=on,apic=on \
  --memory "${VM_MEMORY_MIB}" \
  --vcpus "${VM_CPUS}" \
  --disk "path=${DISK_PATH},size=${VM_DISK_SIZE},bus=virtio,boot.order=1" \
  --os-variant "${OS_VARIANT:-almalinux9}" \
  --network "network=tux2lab,model=virtio,mac=${GENERATED_MAC},boot.order=2" \
  --graphics none \
  --noautoconsole \
  --machine q35 \
  --watchdog none \
  --cpu host-model \
  --boot "loader=${OVMF_CODE_PATH},nvram.template=${OVMF_VARS_PATH}${OVMF_NVRAM_TEMPLATE_FORMAT_OPT},nvram=${NVRAM_PATH},menu=on" \
  --xml ./os/nvram/@format=raw \
  2>&1 >/dev/null); then
    echo "$virt_install_error" >&2
    return 1
fi
